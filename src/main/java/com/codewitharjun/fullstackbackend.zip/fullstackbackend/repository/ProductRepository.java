package com.codewitharjun.fullstackbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codewitharjun.fullstackbackend.model.Products;

public interface ProductRepository extends JpaRepository<Products,Long>{

}
