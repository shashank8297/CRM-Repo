package com.codewitharjun.fullstackbackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.codewitharjun.fullstackbackend.model.Admin;

public interface AdminRepository extends JpaRepository<Admin,Long>{
	
	Admin findByEmail(String email);

	Admin findByPassword(String password);

	Admin findByEmailAndPassword(String email, String password);

}
