package com.codewitharjun.fullstackbackend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.codewitharjun.fullstackbackend.exception.UserNotFoundException;
import com.codewitharjun.fullstackbackend.model.Ticket;
import com.codewitharjun.fullstackbackend.model.User;
import com.codewitharjun.fullstackbackend.repository.TicketRepository;

@RestController
@CrossOrigin("http://localhost:3000")
public class TicketsController {

	@Autowired
	private TicketRepository ticketRepository;

	@PostMapping("/ticket")
	Ticket newTicket(@RequestBody Ticket newTicket) {
		return ticketRepository.save(newTicket);
	}

	@GetMapping("/tickets")
	List<Ticket> getAllTickets() {
		return ticketRepository.findAll();
	}

	@GetMapping("/ticket/{id}")
	Ticket getTicketById(@PathVariable Long id) {
		return ticketRepository.findById(id).orElseThrow(() -> new UserNotFoundException(id));
	}

	@PutMapping("/ticket/{id}")
	Ticket updateTicket(@RequestBody Ticket newTicket, @PathVariable Long id) {
		return ticketRepository.findById(id).map(ticket -> {
			ticket.setUsername(newTicket.getUsername());
			ticket.setEmail(newTicket.getEmail());
			ticket.setIssue(newTicket.getIssue());
			ticket.setStatus(newTicket.getStatus());
			return ticketRepository.save(ticket);
		}).orElseThrow(() -> new UserNotFoundException(id));
	}

	@DeleteMapping("/ticket/{id}")
	String deleteTicket(@PathVariable Long id) {
		if (!ticketRepository.existsById(id)) {
			throw new UserNotFoundException(id);
		}
		ticketRepository.deleteById(id);
		return "User with id " + id + " has been deleted success.";
	}

}
